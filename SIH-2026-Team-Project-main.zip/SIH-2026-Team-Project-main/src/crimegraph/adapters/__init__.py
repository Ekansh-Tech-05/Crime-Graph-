"""Frontend adapter package."""
